package model;

import java.util.ArrayList;

public class Twee {
	
	
	
	
	private String storyTitle;
	private String storyStart;
	
	private ArrayList<Scene> scenes=new ArrayList<Scene>();
	
	public void addScene(int index, Scene scene) {
		scene.setSceneIndex(index);
		scenes.add(index, scene);
	}

	public void setStoryTitle(String storyTitle) {
		this.storyTitle=storyTitle;
	}
	
	public void setStoryStart(String storyStart) {
		this.storyStart = storyStart;
	}

	public String getStoryStart() {
		return this.storyStart;
	}

	public String getStoryTitle() {
		return this.storyTitle;
	}
	
	
	@Override
	public String toString() {
		String result = """
function DialogStructManager(){
	return {
		scenes: 
		[
""";
		result+=scenes.parallelStream().map(Scene::toString).reduce("", String::concat);
					
				result += """

		]
	}
}
""";
				return result;
	}
	

}
