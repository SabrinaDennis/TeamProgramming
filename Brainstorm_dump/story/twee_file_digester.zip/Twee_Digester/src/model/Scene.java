package model;

import java.util.ArrayList;
import java.util.List;

public class Scene{
	
	String sceneName = new String();
	String sceneText = new String();
	List<Option> options = new ArrayList<Option>();
	
	public void setSceneName(String sceneName) {
		this.sceneName=sceneName;
	}
	
	public void setSceneText(String sceneText) {
		this.sceneText=sceneText;
	}
	
	public void addOption(Option option) {
		options.add(option);
	}
	
	
	public Scene(String sceneName, String sceneText){
		this.sceneName=sceneName;
		this.sceneText=sceneText;
		
		options = new ArrayList<Option>();
	}

	public Scene() { }
	
	@Override
	public String toString(){
		String result = "n: "+this.sceneName+"\n"
				+"t: "+this.sceneText+"\n"
				+options.size();
		for(int i=0;i<options.size();i++) {
			result+=options.get(i).toString()+"\n";
		}
		return result;
	}
}