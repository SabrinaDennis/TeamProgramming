package model;

import java.util.ArrayList;
import java.util.List;

public class Scene{
	int sceneIndex;
	String sceneName = new String();
	String sceneText = new String();
	String sceneRawContent = new String();
	List<Option> options = new ArrayList<Option>();
	
	
	@Override
	public String toString(){
		String result="\n\t\t\t{"+"\n\t\t\t\t"+"sceneIndex: "+this.sceneIndex+",\n\t\t\t\t"
				+"sceneName: \""+ this.sceneName+"\",\n\t\t\t\t"
				+this.sceneRawContent+",\n\t\t\t\t"
						+ "sceneText: \""+this.sceneText.trim().replace("\"", "\\\\\"")
						.replace("\n\n","\n")
						.replace("\n", "\\n")
						+"\",\n\t\t\t\t"
						+ "options: [\n\t\t\t\t\t";		
			for(int i=0;i<options.size();i++) {
				result+=options.get(i).toString()+",\n\t\t\t\t\t";
			}
		result+="]\n\t\t\t\t},";
		return result;
	}
	public void setSceneName(String sceneName) {
		this.sceneName=sceneName;
	}
	
	public void setSceneText(String sceneText) {
		this.sceneText=sceneText;
	}
	public void setSceneRawContent(String rawContent) {
		this.sceneRawContent=rawContent;
	}
	public void addOption(Option option) {
		options.add(option);
	}
	
	
	public Scene(String sceneName,String rawContent, String sceneText){
		this.sceneName=sceneName;
		this.sceneText=sceneText;
		this.sceneRawContent=rawContent.substring("/* rawContent */".length());
		
		
		options = new ArrayList<Option>();
	}

	public Scene() { }
	
	public void setSceneIndex(int index) {
		this.sceneIndex=index;
	}
}