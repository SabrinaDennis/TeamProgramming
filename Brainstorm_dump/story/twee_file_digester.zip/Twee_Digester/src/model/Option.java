package model;

public class Option{
	String text = new String();
	String function = new String();
	String parameters;
	
	public Option(String text, String function, String parameters){
		this.text = new String(text);
		this.function = new String(function);
		this.parameters = new String(parameters);
	}
	@Override
	public String toString(){
		return text + " | " + function + " | "+ parameters;
	}
}