package file_operations;

import java.io.BufferedWriter;
import java.io.FileWriter;

import model.Twee;

public class FileSaver {
	public static void saveToGML(Twee twee) {
		try(BufferedWriter writer = new BufferedWriter(new FileWriter("output.gml"))){
			writer.write(twee.toString());
			writer.close();
		}
		catch (Exception e) {
			
		}
	}
}
