package file_operations;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import model.Option;
import model.Scene;
import model.Twee;

public class FileLoader {
	private static Twee twee;

	String filePath = new String();

	public static Twee loadTwee(String fileName) {
		twee=new Twee();
		String line = new String();
		Map<String, String> allSections = new HashMap<String, String>();
		String header = new String();
		String content = new String();
		try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
			
			header = reader.readLine();
			header = "StoryTitle";
			while ((line = reader.readLine()) != null) {
				if(line.startsWith(":: ")) {
					allSections.put(header, content);
					header = line.substring(3).replaceFirst(" \\{.*$", "");
					line= new String();
					content=new String();
				} else {
					content=content+'\n'+line;
				}
				allSections.put(header, content);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Pattern pattern = Pattern.compile("^  \"start\": \"(.*)\",$", Pattern.MULTILINE);
		Matcher matcher = pattern.matcher(allSections.get("StoryData"));
		twee.setStoryStart(matcher.find()+matcher.group(1));
		twee.setStoryTitle(allSections.get("StoryTitle").trim());
		
		allSections.remove(null);
		allSections.remove("StoryTitle");
		allSections.remove("StoryData");
		
		List<String> allKeys = new ArrayList<String>(allSections.keySet());
		
		for(int index=0; index<allKeys.size();index++) {
		content = allSections.get(allKeys.get(index));
		pattern = Pattern.compile("\\[\\[(.*)\\]\\]");
		matcher = pattern.matcher(content);
		Scene tempScene = new Scene(allKeys.get(index), content);
		matcher.results().forEach(m->tempScene.addOption(new Option(m.group(1), "goToSceneIndex", "["+allKeys.indexOf(m.group(1))+"]")));	
		twee.addScene(index, tempScene);
		}
		return twee;
	}
}
