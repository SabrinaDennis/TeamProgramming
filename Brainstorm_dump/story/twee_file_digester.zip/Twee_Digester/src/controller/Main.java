package controller;

import file_operations.FileLoader;
import file_operations.FileSaver;
import model.Twee;

public class Main {

	public static void main(String[] args) {
		Twee twee = new Twee();
		twee = FileLoader.loadTwee("C:\\Users\\benja\\CPS298\\repo\\TeamProgramming\\Brainstorm_dump\\story\\story_files\\TextAdventureGame.twee");
	System.out.println(twee);
		FileSaver.saveToGML(twee);
	}
	
}
